// +build ignore

// Ignored package
package nested
